import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Download, i as Eraser, n as Terminal, o as Clipboard, r as Shuffle, s as Check } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BtPGk0uM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium tracking-tight transition-[transform,background-color,box-shadow,color,opacity] duration-150 ease-out focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:bg-fg",
			secondary: "bg-raised text-fg shadow-border hover:shadow-border-hover",
			ghost: "text-muted hover:bg-raised hover:text-fg",
			danger: "bg-danger/15 text-danger hover:bg-danger/25"
		},
		size: {
			sm: "h-9 rounded-sm px-3 text-sm",
			md: "h-11 rounded-sm px-3.5 text-sm",
			lg: "h-12 rounded-md px-4 text-sm",
			icon: "size-11 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = (0, import_react.forwardRef)(({ className, variant, size, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	ref,
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	...props
}));
Button.displayName = "Button";
function SwitchRow({ checked, onCheckedChange, label, hint, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("flex min-h-11 cursor-pointer items-center justify-between gap-3 rounded-sm px-1", disabled && "pointer-events-none opacity-40"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-sm font-medium text-fg",
				children: label
			}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block text-xs text-muted",
				children: hint
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			role: "switch",
			"aria-checked": checked,
			"aria-label": label,
			disabled,
			onClick: () => onCheckedChange(!checked),
			className: cn("relative h-6 w-10 shrink-0 rounded-full transition-colors duration-150 ease-out", checked ? "bg-accent" : "bg-faint"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 left-0.5 size-5 rounded-full transition-transform duration-150 ease-out", checked ? "translate-x-4 bg-accent-fg" : "translate-x-0 bg-muted") })
		})]
	});
}
var ParseError = class extends Error {
	line;
	column;
	constructor(message, line, column) {
		super(`${message} (${line}:${column})`);
		this.name = "ParseError";
		this.line = line;
		this.column = column;
	}
};
var PREC$1 = {
	or: { p: 1 },
	and: { p: 2 },
	"<": { p: 3 },
	">": { p: 3 },
	"<=": { p: 3 },
	">=": { p: 3 },
	"~=": { p: 3 },
	"==": { p: 3 },
	"..": {
		p: 4,
		right: true
	},
	"+": { p: 5 },
	"-": { p: 5 },
	"*": { p: 6 },
	"/": { p: 6 },
	"//": { p: 6 },
	"%": { p: 6 },
	"^": {
		p: 9,
		right: true
	}
};
var UNARY$1 = 8;
function emit(chunk, options = {}) {
	return new Emitter(options).emitChunk(chunk);
}
var Emitter = class {
	minify;
	indent = 0;
	out = "";
	last = "";
	constructor(options) {
		this.minify = Boolean(options.minify);
	}
	emitChunk(chunk) {
		this.out = "";
		this.last = "";
		this.emitStats(chunk.body);
		return this.out;
	}
	write(s) {
		if (!s) return;
		if (this.out && needsSpace(this.last, s[0] ?? "")) this.out += " ";
		this.out += s;
		this.last = s[s.length - 1] ?? "";
	}
	nl() {
		if (this.minify) {
			if (this.out && this.last !== ";") {
				this.out += ";";
				this.last = ";";
			}
			return;
		}
		this.out += "\n" + "  ".repeat(this.indent);
		this.last = "\n";
	}
	emitStats(stats) {
		for (let i = 0; i < stats.length; i++) {
			if (i > 0) this.nl();
			else if (this.out && !this.minify) this.nl();
			const s = stats[i];
			if (this.minify && startsAmbiguous(s)) this.write(";");
			this.emitStat(s);
		}
	}
	emitStat(s) {
		switch (s.type) {
			case "Assignment":
				this.emitVarList(s.vars);
				this.write(s.compound ?? "=");
				this.emitExpList(s.exps);
				break;
			case "CallStat":
				this.emitExp(s.call, 0);
				break;
			case "Do":
				this.write("do");
				this.indent += 1;
				this.emitStats(s.body);
				this.indent -= 1;
				this.nl();
				this.write("end");
				break;
			case "While":
				this.write("while");
				this.emitExp(s.cond, 0);
				this.write("do");
				this.indent += 1;
				this.emitStats(s.body);
				this.indent -= 1;
				this.nl();
				this.write("end");
				break;
			case "Repeat":
				this.write("repeat");
				this.indent += 1;
				this.emitStats(s.body);
				this.indent -= 1;
				this.nl();
				this.write("until");
				this.emitExp(s.cond, 0);
				break;
			case "If":
				s.clauses.forEach((c, idx) => {
					this.write(idx === 0 ? "if" : "elseif");
					this.emitExp(c.test, 0);
					this.write("then");
					this.indent += 1;
					this.emitStats(c.body);
					this.indent -= 1;
					this.nl();
				});
				if (s.otherwise) {
					this.write("else");
					this.indent += 1;
					this.emitStats(s.otherwise);
					this.indent -= 1;
					this.nl();
				}
				this.write("end");
				break;
			case "ForNum":
				this.write("for");
				this.write(s.name);
				this.write("=");
				this.emitExp(s.start, 0);
				this.write(",");
				this.emitExp(s.last, 0);
				if (s.step) {
					this.write(",");
					this.emitExp(s.step, 0);
				}
				this.write("do");
				this.indent += 1;
				this.emitStats(s.body);
				this.indent -= 1;
				this.nl();
				this.write("end");
				break;
			case "ForIn":
				this.write("for");
				s.names.forEach((n, i) => {
					if (i) this.write(",");
					this.write(n);
				});
				this.write("in");
				this.emitExpList(s.exps);
				this.write("do");
				this.indent += 1;
				this.emitStats(s.body);
				this.indent -= 1;
				this.nl();
				this.write("end");
				break;
			case "FunctionStat":
				this.write("function");
				this.write(s.name.parts.join("."));
				if (s.name.method) {
					this.write(":");
					this.write(s.name.method);
				}
				this.emitFuncBody(s.body, Boolean(s.name.method));
				break;
			case "LocalFunction":
				this.write("local function");
				this.write(s.name);
				this.emitFuncBody(s.body, false);
				break;
			case "Local":
				this.write("local");
				s.names.forEach((n, i) => {
					if (i) this.write(",");
					this.write(n);
				});
				if (s.exps) {
					this.write("=");
					this.emitExpList(s.exps);
				}
				break;
			case "Return":
				this.write("return");
				if (s.exps?.length) this.emitExpList(s.exps);
				break;
			case "Break":
				this.write("break");
				break;
			case "Continue": this.write("continue");
		}
	}
	emitFuncBody(body, method) {
		this.write("(");
		const params = method ? body.params.filter((p, i) => !(i === 0 && p === "self")) : body.params;
		params.forEach((p, i) => {
			if (i) this.write(",");
			this.write(p);
		});
		if (body.vararg) {
			if (params.length) this.write(",");
			this.write("...");
		}
		this.write(")");
		this.indent += 1;
		this.emitStats(body.body);
		this.indent -= 1;
		this.nl();
		this.write("end");
	}
	emitVarList(vars) {
		vars.forEach((v, i) => {
			if (i) this.write(",");
			this.emitExp(v, 0);
		});
	}
	emitExpList(exps) {
		exps.forEach((e, i) => {
			if (i) this.write(",");
			this.emitExp(e, 0);
		});
	}
	emitExp(e, parent) {
		switch (e.type) {
			case "Nil":
				this.write("nil");
				return;
			case "Boolean":
				this.write(e.value ? "true" : "false");
				return;
			case "Number":
				this.write(formatNumber(e.value, e.raw));
				return;
			case "String":
				this.write(quoteLua(e.value));
				return;
			case "Vararg":
				this.write("...");
				return;
			case "Name":
				this.write(e.name);
				return;
			case "Paren":
				this.write("(");
				this.emitExp(e.exp, 0);
				this.write(")");
				return;
			case "Unary": {
				const wrap = parent > UNARY$1;
				if (wrap) this.write("(");
				this.write(e.op);
				this.emitExp(e.arg, UNARY$1);
				if (wrap) this.write(")");
				return;
			}
			case "Binary": {
				const info = PREC$1[e.op];
				const wrap = info.p < parent || info.p === parent && !info.right;
				if (wrap) this.write("(");
				this.emitExp(e.left, info.right ? info.p + 1 : info.p);
				this.write(e.op);
				this.emitExp(e.right, info.right ? info.p : info.p + 1);
				if (wrap) this.write(")");
				return;
			}
			case "Table":
				this.write("{");
				e.fields.forEach((f, i) => {
					if (i) this.write(",");
					this.emitField(f);
				});
				this.write("}");
				return;
			case "Function":
				this.write("function");
				this.emitFuncBody(e.body, false);
				return;
			case "Index":
				this.emitExp(e.object, 10);
				this.write("[");
				this.emitExp(e.key, 0);
				this.write("]");
				return;
			case "Member":
				this.emitExp(e.object, 10);
				if (isIdent(e.name)) {
					this.write(".");
					this.write(e.name);
				} else {
					this.write("[");
					this.write(quoteLua(e.name));
					this.write("]");
				}
				return;
			case "Call":
				this.emitExp(e.callee, 10);
				if (e.method) {
					this.write(":");
					this.write(e.method);
				}
				this.write("(");
				e.args.forEach((a, i) => {
					if (i) this.write(",");
					this.emitExp(a, 0);
				});
				this.write(")");
				return;
			case "IfExp": {
				const wrap = parent > 0;
				if (wrap) this.write("(");
				e.clauses.forEach((c, i) => {
					this.write(i === 0 ? "if" : "elseif");
					this.emitExp(c.test, 0);
					this.write("then");
					this.emitExp(c.value, 0);
				});
				this.write("else");
				this.emitExp(e.otherwise, 0);
				if (wrap) this.write(")");
				return;
			}
		}
	}
	emitField(f) {
		if (f.kind === "list") {
			this.emitExp(f.value, 0);
			return;
		}
		if (f.kind === "rec" && isIdent(f.name)) {
			this.write(f.name);
			this.write("=");
			this.emitExp(f.value, 0);
			return;
		}
		this.write("[");
		if (f.kind === "rec") this.write(quoteLua(f.name));
		else this.emitExp(f.key, 0);
		this.write("]");
		this.write("=");
		this.emitExp(f.value, 0);
	}
};
function needsSpace(prev, next) {
	const id = (c) => /[A-Za-z0-9_]/.test(c);
	if (id(prev) && id(next)) return true;
	if (prev === "-" && next === "-") return true;
	if (prev === "." && next === ".") return true;
	return false;
}
function startsAmbiguous(s) {
	if (s.type === "CallStat") return s.call.callee.type === "Paren" || s.call.callee.type === "Function";
	if (s.type === "Assignment") {
		const v = s.vars[0];
		return Boolean(v && (v.type === "Paren" || v.type === "Index"));
	}
	return false;
}
function isIdent(name) {
	return /^[A-Za-z_][A-Za-z0-9_]*$/.test(name);
}
function formatNumber(value, raw) {
	if (raw && !raw.includes("_") && Number(raw.replace(/_/g, "")) === value) {
		if (/^0[xXbB]/.test(raw) || /^[0-9.]+$/.test(raw)) return raw;
	}
	if (Number.isInteger(value) && Math.abs(value) <= Number.MAX_SAFE_INTEGER) return String(value);
	return String(value);
}
function quoteLua(value) {
	let single = 0;
	let dbl = 0;
	for (const ch of value) if (ch === "'") single += 1;
	else if (ch === "\"") dbl += 1;
	const q = single <= dbl ? "'" : "\"";
	let out = q;
	for (const ch of value) {
		const code = ch.charCodeAt(0);
		if (ch === "\\") out += "\\\\";
		else if (ch === q) out += "\\" + q;
		else if (ch === "\n") out += "\\n";
		else if (ch === "\r") out += "\\r";
		else if (ch === "	") out += "\\t";
		else if (ch === "\0") out += "\\000";
		else if (code < 32 || code > 126) out += "\\" + String(code).padStart(3, "0");
		else out += ch;
	}
	out += q;
	return out;
}
var KEYWORDS = /* @__PURE__ */ new Set([
	"and",
	"break",
	"do",
	"else",
	"elseif",
	"end",
	"false",
	"for",
	"function",
	"if",
	"in",
	"local",
	"nil",
	"not",
	"or",
	"repeat",
	"return",
	"then",
	"true",
	"until",
	"while",
	"continue"
]);
var OPS = [
	"...",
	"..=",
	"..",
	"//=",
	"//",
	"+=",
	"-=",
	"*=",
	"/=",
	"%=",
	"^=",
	"==",
	"~=",
	"!=",
	"<=",
	">=",
	"::",
	"->",
	"+",
	"-",
	"*",
	"/",
	"%",
	"^",
	"#",
	"<",
	">",
	"=",
	"(",
	")",
	"{",
	"}",
	"[",
	"]",
	";",
	":",
	",",
	"."
];
function tokenize(source) {
	const tokens = [];
	let i = 0;
	const n = source.length;
	let line = 1;
	let col = 1;
	const peek = (k = 0) => source[i + k] ?? "";
	const at = () => ({
		line,
		column: col
	});
	function advance(count = 1) {
		for (let k = 0; k < count; k++) {
			if (source[i] === "\n") {
				line += 1;
				col = 1;
			} else col += 1;
			i += 1;
		}
	}
	function startsLong(from, opener) {
		let p = from;
		if (opener === "--[") {
			if (source.slice(from, from + 3) !== "--[") return null;
			p = from + 3;
		} else {
			if (source[from] !== "[") return null;
			p = from + 1;
		}
		let eq = 0;
		while (source[p] === "=") {
			eq += 1;
			p += 1;
		}
		if (source[p] !== "[") return null;
		return { eq };
	}
	function readLong(eq, startAdvance) {
		advance(startAdvance);
		const close = "]" + "=".repeat(eq) + "]";
		const start = i;
		const idx = source.indexOf(close, i);
		if (idx < 0) throw new ParseError("unfinished long string", line, col);
		const value = source.slice(start, idx);
		advance(idx + close.length - i);
		return value;
	}
	function readShortString(q) {
		const pos = at();
		advance();
		let out = "";
		while (i < n) {
			const c = peek();
			if (c === q) {
				advance();
				return out;
			}
			if (c === "\n") throw new ParseError("unfinished string", pos.line, pos.column);
			if (c === "\\") {
				advance();
				const e = peek();
				const map = {
					a: "\x07",
					b: "\b",
					f: "\f",
					n: "\n",
					r: "\r",
					t: "	",
					v: "\v",
					"\\": "\\",
					"\"": "\"",
					"'": "'",
					"`": "`",
					"\n": "\n"
				};
				if (e in map) {
					out += map[e];
					advance();
					continue;
				}
				if (e === "x") {
					const hex = source.slice(i + 1, i + 3);
					if (!/^[0-9a-fA-F]{2}$/.test(hex)) throw new ParseError("invalid hex escape", line, col);
					out += String.fromCharCode(parseInt(hex, 16));
					advance(3);
					continue;
				}
				if (e === "u") {
					if (peek(1) !== "{") throw new ParseError("invalid unicode escape", line, col);
					let j = i + 2;
					while (source[j] && source[j] !== "}") j += 1;
					const hex = source.slice(i + 2, j);
					out += String.fromCodePoint(parseInt(hex, 16) || 0);
					advance(j + 1 - i);
					continue;
				}
				if (/[0-9]/.test(e)) {
					let j = 0;
					let digits = "";
					while (j < 3 && /[0-9]/.test(peek(j))) {
						digits += peek(j);
						j += 1;
					}
					out += String.fromCharCode(parseInt(digits, 10) % 256);
					advance(j);
					continue;
				}
				if (e === "z") {
					advance();
					while (/\s/.test(peek())) advance();
					continue;
				}
				out += e;
				advance();
				continue;
			}
			out += c;
			advance();
		}
		throw new ParseError("unfinished string", pos.line, pos.column);
	}
	function readInterp() {
		const pos = at();
		advance();
		let raw = "";
		while (i < n) {
			const c = peek();
			if (c === "`") {
				advance();
				return raw;
			}
			if (c === "\\") {
				raw += c;
				advance();
				if (i < n) {
					raw += peek();
					advance();
				}
				continue;
			}
			raw += c;
			advance();
		}
		throw new ParseError("unfinished interpolated string", pos.line, pos.column);
	}
	function readNumber() {
		const start = i;
		if (peek() === "0" && /[xX]/.test(peek(1))) {
			advance(2);
			while (/[0-9a-fA-F_]/.test(peek())) advance();
			if (/[pP]/.test(peek())) {
				advance();
				if (/[+-]/.test(peek())) advance();
				while (/[0-9_]/.test(peek())) advance();
			}
			return source.slice(start, i);
		}
		if (peek() === "0" && /[bB]/.test(peek(1))) {
			advance(2);
			while (/[01_]/.test(peek())) advance();
			return source.slice(start, i);
		}
		while (/[0-9_]/.test(peek())) advance();
		if (peek() === "." && peek(1) !== ".") {
			advance();
			while (/[0-9_]/.test(peek())) advance();
		}
		if (/[eE]/.test(peek())) {
			advance();
			if (/[+-]/.test(peek())) advance();
			while (/[0-9_]/.test(peek())) advance();
		}
		return source.slice(start, i);
	}
	while (i < n) {
		const c = peek();
		if (c === " " || c === "	" || c === "\r" || c === "\n" || c === "\v" || c === "\f") {
			advance();
			continue;
		}
		if (c === "-" && peek(1) === "-") {
			const long = startsLong(i, "--[");
			if (long) {
				const extra = 3 + long.eq + 1;
				readLong(long.eq, extra);
				continue;
			}
			while (i < n && peek() !== "\n") advance();
			continue;
		}
		if (c === "#" && line === 1 && col === 1) {
			while (i < n && peek() !== "\n") advance();
			continue;
		}
		const longStr = startsLong(i, "[");
		if (longStr) {
			const extra = 1 + longStr.eq + 1;
			const value = readLong(longStr.eq, extra);
			tokens.push({
				kind: "string",
				value,
				...at()
			});
			continue;
		}
		if (c === "\"" || c === "'") {
			const pos = at();
			const value = readShortString(c);
			tokens.push({
				kind: "string",
				value,
				...pos
			});
			continue;
		}
		if (c === "`") {
			const pos = at();
			const value = readInterp();
			tokens.push({
				kind: "interp",
				value,
				...pos
			});
			continue;
		}
		if (/[0-9]/.test(c) || c === "." && /[0-9]/.test(peek(1))) {
			const pos = at();
			const value = readNumber();
			tokens.push({
				kind: "number",
				value,
				...pos
			});
			continue;
		}
		if (/[A-Za-z_]/.test(c) || c.charCodeAt(0) > 127) {
			const pos = at();
			let value = "";
			while (i < n && (/[A-Za-z0-9_]/.test(peek()) || peek().charCodeAt(0) > 127)) {
				value += peek();
				advance();
			}
			tokens.push({
				kind: KEYWORDS.has(value) ? "keyword" : "name",
				value,
				...pos
			});
			continue;
		}
		let matched = "";
		for (const op of OPS) if (source.startsWith(op, i)) {
			matched = op;
			break;
		}
		if (matched) {
			const pos = at();
			advance(matched.length);
			tokens.push({
				kind: "op",
				value: matched,
				...pos
			});
			continue;
		}
		throw new ParseError(`unexpected character ${JSON.stringify(c)}`, line, col);
	}
	tokens.push({
		kind: "eof",
		value: "",
		line,
		column: col
	});
	return tokens;
}
function isKeyword(tok, word) {
	return tok.kind === "keyword" && tok.value === word;
}
var COMPOUND = /* @__PURE__ */ new Set([
	"+=",
	"-=",
	"*=",
	"/=",
	"%=",
	"^=",
	"..=",
	"//="
]);
var UNARY = {
	not: 8,
	"#": 8,
	"-": 8
};
var PREC = {
	or: { p: 1 },
	and: { p: 2 },
	"<": { p: 3 },
	">": { p: 3 },
	"<=": { p: 3 },
	">=": { p: 3 },
	"~=": { p: 3 },
	"!=": { p: 3 },
	"==": { p: 3 },
	"..": {
		p: 4,
		right: true
	},
	"+": { p: 5 },
	"-": { p: 5 },
	"*": { p: 6 },
	"/": { p: 6 },
	"//": { p: 6 },
	"%": { p: 6 },
	"^": {
		p: 9,
		right: true
	}
};
function parse(source) {
	return new Parser(source).parseChunk();
}
var Parser = class Parser {
	tokens;
	i = 0;
	source;
	constructor(source) {
		this.source = source;
		this.tokens = tokenize(source);
	}
	tok() {
		return this.tokens[this.i] ?? this.tokens[this.tokens.length - 1];
	}
	peekKind() {
		const t = this.tok();
		if (t.kind === "keyword" || t.kind === "op") return t.value;
		return t.kind;
	}
	at(kind, value) {
		const t = this.tok();
		if (value !== void 0) return t.kind === kind && t.value === value;
		if (t.kind === "keyword" || t.kind === "op") return t.value === kind;
		return t.kind === kind;
	}
	eat(kind, value) {
		if (this.at(kind, value)) {
			const t = this.tok();
			this.i += 1;
			return t;
		}
		return null;
	}
	expect(kind, value) {
		const t = this.eat(kind, value);
		if (t) return t;
		const cur = this.tok();
		throw new ParseError(`expected ${value ?? kind}, got ${cur.value || cur.kind}`, cur.line, cur.column);
	}
	err(msg) {
		const t = this.tok();
		throw new ParseError(msg, t.line, t.column);
	}
	parseChunk() {
		const body = this.parseBlock();
		if (!this.at("eof")) this.err("expected end of file");
		return {
			type: "Chunk",
			body
		};
	}
	parseBlock(terminators = []) {
		const body = [];
		while (!this.at("eof")) {
			const k = this.peekKind();
			if (terminators.includes(k)) break;
			if (k === "end" || k === "else" || k === "elseif" || k === "until") break;
			if (this.eat("op", ";")) continue;
			if (k === "return") {
				body.push(this.parseReturn());
				this.eat("op", ";");
				break;
			}
			const stat = this.parseStat();
			if (stat) body.push(stat);
			this.eat("op", ";");
		}
		return body;
	}
	parseStat() {
		if (isKeyword(this.tok(), "do")) {
			this.i += 1;
			const body = this.parseBlock();
			this.expect("keyword", "end");
			return {
				type: "Do",
				body
			};
		}
		if (isKeyword(this.tok(), "while")) {
			this.i += 1;
			const cond = this.parseExp();
			this.expect("keyword", "do");
			const body = this.parseBlock();
			this.expect("keyword", "end");
			return {
				type: "While",
				cond,
				body
			};
		}
		if (isKeyword(this.tok(), "repeat")) {
			this.i += 1;
			const body = this.parseBlock(["until"]);
			this.expect("keyword", "until");
			return {
				type: "Repeat",
				body,
				cond: this.parseExp()
			};
		}
		if (isKeyword(this.tok(), "if")) return this.parseIf();
		if (isKeyword(this.tok(), "for")) return this.parseFor();
		if (isKeyword(this.tok(), "function")) {
			this.i += 1;
			return {
				type: "FunctionStat",
				name: this.parseFuncName(),
				body: this.parseFuncBody()
			};
		}
		if (isKeyword(this.tok(), "local")) return this.parseLocal();
		if (isKeyword(this.tok(), "break")) {
			this.i += 1;
			return { type: "Break" };
		}
		if (isKeyword(this.tok(), "continue")) {
			this.i += 1;
			return { type: "Continue" };
		}
		if (isKeyword(this.tok(), "type") || this.at("name", "type") && this.looksLikeTypeAlias()) {
			this.skipTypeAlias();
			return {
				type: "Do",
				body: []
			};
		}
		if (this.at("name", "export") && this.looksLikeExportType()) {
			this.skipTypeAlias();
			return {
				type: "Do",
				body: []
			};
		}
		const first = this.parsePrefix();
		if (this.at("op", ",") || this.at("op", "=") || COMPOUND.has(this.tok().value)) {
			const vars = [first];
			while (this.eat("op", ",")) vars.push(this.parsePrefix());
			const opTok = this.tok();
			if (COMPOUND.has(opTok.value)) {
				this.i += 1;
				if (vars.length !== 1) this.err("compound assignment needs one target");
				return {
					type: "Assignment",
					vars,
					exps: this.parseExpList(),
					compound: opTok.value
				};
			}
			this.expect("op", "=");
			return {
				type: "Assignment",
				vars,
				exps: this.parseExpList()
			};
		}
		if (first.type === "Call") return {
			type: "CallStat",
			call: first
		};
		this.err("expected statement");
	}
	looksLikeTypeAlias() {
		const next = this.tokens[this.i + 1];
		if (!next || next.kind !== "name") return false;
		const after = this.tokens[this.i + 2];
		return Boolean(after && after.kind === "op" && (after.value === "=" || after.value === "<"));
	}
	looksLikeExportType() {
		const next = this.tokens[this.i + 1];
		return Boolean(next && (next.kind === "name" && next.value === "type" || next.kind === "keyword" && next.value === "type"));
	}
	skipTypeAlias() {
		if (this.at("name", "export")) this.i += 1;
		if (this.at("name", "type") || isKeyword(this.tok(), "type")) this.i += 1;
		if (this.at("name")) this.i += 1;
		if (this.at("op", "<")) this.skipBalanced("<", ">");
		if (this.at("op", "=")) this.i += 1;
		this.skipType();
	}
	skipBalanced(open, close) {
		let depth = 0;
		do {
			const t = this.tok();
			if (t.kind === "eof") this.err("unfinished type");
			if (t.kind === "op" && t.value === open) depth += 1;
			else if (t.kind === "op" && t.value === close) depth -= 1;
			this.i += 1;
		} while (depth > 0);
	}
	skipType() {
		let depth = 0;
		while (!this.at("eof")) {
			const t = this.tok();
			const v = t.value;
			if (depth === 0) {
				if (t.kind === "op" && (v === "," || v === ")" || v === ";" || v === "=")) break;
				if (t.kind === "keyword" && [
					"end",
					"then",
					"do",
					"else",
					"elseif",
					"until",
					"in"
				].includes(v)) break;
			}
			if (t.kind === "op" && (v === "(" || v === "{" || v === "[" || v === "<")) {
				depth += 1;
				this.i += 1;
				continue;
			}
			if (t.kind === "op" && (v === ")" || v === "}" || v === "]" || v === ">")) {
				if (depth === 0) break;
				depth -= 1;
				this.i += 1;
				continue;
			}
			this.i += 1;
			if (depth === 0 && t.kind === "op" && v === "->") continue;
		}
	}
	parseIf() {
		this.expect("keyword", "if");
		const clauses = [];
		const test = this.parseExp();
		this.expect("keyword", "then");
		clauses.push({
			test,
			body: this.parseBlock()
		});
		while (isKeyword(this.tok(), "elseif")) {
			this.i += 1;
			const t = this.parseExp();
			this.expect("keyword", "then");
			clauses.push({
				test: t,
				body: this.parseBlock()
			});
		}
		let otherwise;
		if (isKeyword(this.tok(), "else")) {
			this.i += 1;
			otherwise = this.parseBlock();
		}
		this.expect("keyword", "end");
		return {
			type: "If",
			clauses,
			otherwise
		};
	}
	parseFor() {
		this.expect("keyword", "for");
		const first = this.expect("name").value;
		this.maybeSkipTypeAnnot();
		if (this.eat("op", "=")) {
			const start = this.parseExp();
			this.expect("op", ",");
			const last = this.parseExp();
			let step;
			if (this.eat("op", ",")) step = this.parseExp();
			this.expect("keyword", "do");
			const body = this.parseBlock();
			this.expect("keyword", "end");
			return {
				type: "ForNum",
				name: first,
				start,
				last,
				step,
				body
			};
		}
		const names = [first];
		while (this.eat("op", ",")) {
			names.push(this.expect("name").value);
			this.maybeSkipTypeAnnot();
		}
		this.expect("keyword", "in");
		const exps = this.parseExpList();
		this.expect("keyword", "do");
		const body = this.parseBlock();
		this.expect("keyword", "end");
		return {
			type: "ForIn",
			names,
			exps,
			body
		};
	}
	parseLocal() {
		this.expect("keyword", "local");
		if (isKeyword(this.tok(), "function")) {
			this.i += 1;
			const name = this.expect("name").value;
			this.maybeSkipGenerics();
			return {
				type: "LocalFunction",
				name,
				body: this.parseFuncBody()
			};
		}
		const names = [this.expect("name").value];
		this.maybeSkipGenerics();
		this.maybeSkipTypeAnnot();
		while (this.eat("op", ",")) {
			names.push(this.expect("name").value);
			this.maybeSkipGenerics();
			this.maybeSkipTypeAnnot();
		}
		let exps;
		if (this.eat("op", "=")) exps = this.parseExpList();
		return {
			type: "Local",
			names,
			exps
		};
	}
	maybeSkipGenerics() {
		if (this.at("op", "<")) this.skipBalanced("<", ">");
	}
	maybeSkipTypeAnnot() {
		if (this.eat("op", ":") || this.eat("op", "::")) this.skipType();
	}
	parseReturn() {
		this.expect("keyword", "return");
		const k = this.peekKind();
		if (k === "eof" || k === ";" || k === "end" || k === "else" || k === "elseif" || k === "until") return { type: "Return" };
		return {
			type: "Return",
			exps: this.parseExpList()
		};
	}
	parseFuncName() {
		const parts = [this.expect("name").value];
		while (this.eat("op", ".")) parts.push(this.expect("name").value);
		let method;
		if (this.eat("op", ":")) method = this.expect("name").value;
		return {
			parts,
			method
		};
	}
	parseFuncBody() {
		this.maybeSkipGenerics();
		this.expect("op", "(");
		const params = [];
		let vararg = false;
		if (!this.at("op", ")")) while (true) {
			if (this.eat("op", "...")) {
				vararg = true;
				this.maybeSkipTypeAnnot();
				break;
			}
			params.push(this.expect("name").value);
			this.maybeSkipTypeAnnot();
			if (!this.eat("op", ",")) break;
		}
		this.expect("op", ")");
		this.maybeSkipTypeAnnot();
		const body = this.parseBlock();
		this.expect("keyword", "end");
		return {
			params,
			vararg,
			body
		};
	}
	parseExpList() {
		const list = [this.parseExp()];
		while (this.eat("op", ",")) list.push(this.parseExp());
		return list;
	}
	parseExp(minPrec = 0) {
		let left = this.parsePrefixExp();
		for (;;) {
			if (this.eat("op", "::")) {
				this.skipType();
				continue;
			}
			const t = this.tok();
			const op = t.kind === "keyword" || t.kind === "op" ? t.value : "";
			const info = PREC[op];
			if (!info || info.p < minPrec) break;
			this.i += 1;
			const nextMin = info.right ? info.p : info.p + 1;
			const right = this.parseExp(nextMin);
			left = {
				type: "Binary",
				op: op === "!=" ? "~=" : op,
				left,
				right
			};
		}
		return left;
	}
	parsePrefixExp() {
		const t = this.tok();
		if (t.kind === "keyword" && t.value === "not") {
			this.i += 1;
			return {
				type: "Unary",
				op: "not",
				arg: this.parseExp(UNARY.not)
			};
		}
		if (t.kind === "op" && (t.value === "-" || t.value === "#")) {
			this.i += 1;
			return {
				type: "Unary",
				op: t.value,
				arg: this.parseExp(UNARY[t.value])
			};
		}
		return this.parsePrimary();
	}
	parsePrimary() {
		const t = this.tok();
		if (isKeyword(t, "nil")) {
			this.i += 1;
			return { type: "Nil" };
		}
		if (isKeyword(t, "true") || isKeyword(t, "false")) {
			this.i += 1;
			return {
				type: "Boolean",
				value: t.value === "true"
			};
		}
		if (t.kind === "number") {
			this.i += 1;
			return {
				type: "Number",
				value: Number(t.value.replace(/_/g, "")),
				raw: t.value
			};
		}
		if (t.kind === "string") {
			this.i += 1;
			return {
				type: "String",
				value: t.value
			};
		}
		if (t.kind === "interp") {
			this.i += 1;
			return this.interpToExp(t.value);
		}
		if (t.kind === "op" && t.value === "...") {
			this.i += 1;
			return { type: "Vararg" };
		}
		if (isKeyword(t, "function")) {
			this.i += 1;
			return {
				type: "Function",
				body: this.parseFuncBody()
			};
		}
		if (isKeyword(t, "if")) return this.parseIfExp();
		if (t.kind === "op" && t.value === "{") return this.parseTable();
		return this.parsePrefix();
	}
	parseIfExp() {
		this.expect("keyword", "if");
		const clauses = [];
		const test = this.parseExp();
		this.expect("keyword", "then");
		const value = this.parseExp();
		clauses.push({
			test,
			value
		});
		while (isKeyword(this.tok(), "elseif")) {
			this.i += 1;
			const te = this.parseExp();
			this.expect("keyword", "then");
			clauses.push({
				test: te,
				value: this.parseExp()
			});
		}
		this.expect("keyword", "else");
		return {
			type: "IfExp",
			clauses,
			otherwise: this.parseExp()
		};
	}
	parsePrefix() {
		let node;
		if (this.at("op", "(")) {
			this.i += 1;
			const inner = this.parseExp();
			this.expect("op", ")");
			node = {
				type: "Paren",
				exp: inner
			};
		} else if (this.at("name")) node = {
			type: "Name",
			name: this.expect("name").value
		};
		else this.err("expected expression");
		for (;;) {
			if (this.eat("op", "[")) {
				const key = this.parseExp();
				this.expect("op", "]");
				node = {
					type: "Index",
					object: node,
					key
				};
				continue;
			}
			if (this.eat("op", ".")) {
				node = {
					type: "Member",
					object: node,
					name: this.expect("name").value
				};
				continue;
			}
			if (this.eat("op", ":")) {
				const method = this.expect("name").value;
				const args = this.parseArgs();
				if (!args) this.err("expected method arguments");
				node = {
					type: "Call",
					callee: node,
					args,
					method
				};
				continue;
			}
			const args = this.parseArgs();
			if (args) {
				node = {
					type: "Call",
					callee: node,
					args
				};
				continue;
			}
			break;
		}
		return node;
	}
	parseArgs() {
		if (this.eat("op", "(")) {
			if (this.eat("op", ")")) return [];
			const list = this.parseExpList();
			this.expect("op", ")");
			return list;
		}
		if (this.at("op", "{")) return [this.parseTable()];
		if (this.at("string")) return [{
			type: "String",
			value: this.expect("string").value
		}];
		return null;
	}
	parseTable() {
		this.expect("op", "{");
		const fields = [];
		while (!this.at("op", "}") && !this.at("eof")) {
			if (this.eat("op", "[")) {
				const key = this.parseExp();
				this.expect("op", "]");
				this.expect("op", "=");
				fields.push({
					kind: "index",
					key,
					value: this.parseExp()
				});
			} else if (this.at("name") && this.tokens[this.i + 1]?.value === "=") {
				const name = this.expect("name").value;
				this.expect("op", "=");
				fields.push({
					kind: "rec",
					name,
					value: this.parseExp()
				});
			} else fields.push({
				kind: "list",
				value: this.parseExp()
			});
			if (this.eat("op", ",") || this.eat("op", ";")) continue;
			break;
		}
		this.expect("op", "}");
		return {
			type: "Table",
			fields
		};
	}
	interpToExp(raw) {
		const parts = [];
		let buf = "";
		let i = 0;
		const unescape = (s) => s.replace(/\\(.)/g, (_, ch) => {
			return {
				n: "\n",
				t: "	",
				"`": "`",
				"{": "{",
				"}": "}",
				"\\": "\\"
			}[ch] ?? ch;
		});
		while (i < raw.length) {
			if (raw[i] === "\\" && i + 1 < raw.length) {
				buf += unescape(raw.slice(i, i + 2));
				i += 2;
				continue;
			}
			if (raw[i] === "{") {
				if (buf) {
					parts.push({
						type: "String",
						value: buf
					});
					buf = "";
				}
				i += 1;
				let depth = 1;
				const start = i;
				while (i < raw.length && depth > 0) {
					if (raw[i] === "{") depth += 1;
					else if (raw[i] === "}") depth -= 1;
					if (depth > 0) i += 1;
				}
				const inner = raw.slice(start, i);
				i += 1;
				const innerExp = new Parser(inner).parseExp();
				parts.push({
					type: "Call",
					callee: {
						type: "Name",
						name: "tostring"
					},
					args: [innerExp]
				});
				continue;
			}
			buf += raw[i] ?? "";
			i += 1;
		}
		if (buf) parts.push({
			type: "String",
			value: buf
		});
		if (parts.length === 0) return {
			type: "String",
			value: ""
		};
		return parts.reduce((a, b) => ({
			type: "Binary",
			op: "..",
			left: a,
			right: b
		}));
	}
};
var BUILTINS = /* @__PURE__ */ new Set([
	"_G",
	"_VERSION",
	"_ENV",
	"assert",
	"bit32",
	"buffer",
	"collectgarbage",
	"coroutine",
	"debug",
	"delay",
	"elapsedTime",
	"Enum",
	"error",
	"game",
	"gcinfo",
	"getfenv",
	"getmetatable",
	"ipairs",
	"Instance",
	"load",
	"loadstring",
	"math",
	"newproxy",
	"next",
	"os",
	"pairs",
	"pcall",
	"plugin",
	"print",
	"rawequal",
	"rawget",
	"rawlen",
	"rawset",
	"require",
	"script",
	"select",
	"setfenv",
	"setmetatable",
	"settings",
	"shared",
	"spawn",
	"string",
	"table",
	"task",
	"tick",
	"time",
	"tonumber",
	"tostring",
	"type",
	"typeof",
	"unpack",
	"utf8",
	"UserSettings",
	"vector",
	"wait",
	"warn",
	"workspace",
	"xpcall",
	"Axes",
	"BrickColor",
	"CFrame",
	"Color3",
	"ColorSequence",
	"DateTime",
	"DockWidgetPluginGuiInfo",
	"Faces",
	"Font",
	"NumberRange",
	"NumberSequence",
	"OverlapParams",
	"PathWaypoint",
	"PhysicalProperties",
	"Random",
	"Ray",
	"RaycastParams",
	"Rect",
	"Region3",
	"TweenInfo",
	"UDim",
	"UDim2",
	"Vector2",
	"Vector3"
]);
function lookup(scope, name) {
	while (scope) {
		const v = scope.map.get(name);
		if (v) return v;
		scope = scope.parent;
	}
}
function renameLocals(chunk, rng, style) {
	let n = 0;
	const used = new Set(BUILTINS);
	const nextName = () => {
		for (;;) {
			n += 1;
			let name;
			if (style === "short") name = `_${toBase(n, 36)}`;
			else if (style === "hex") name = `_0x${(rng.int(4096) + n * 17).toString(16)}${toBase(n, 16)}`;
			else name = confuseName(n, rng);
			if (!used.has(name) && !BUILTINS.has(name)) {
				used.add(name);
				return name;
			}
		}
	};
	const bind = (scope, name) => {
		if (name === "self" || name === "...") return name;
		const existing = scope.map.get(name);
		if (existing) return existing;
		const mangled = nextName();
		scope.map.set(name, mangled);
		return mangled;
	};
	const walkStats = (stats, scope) => {
		for (const s of stats) walkStat(s, scope);
	};
	const walkBody = (body, parent, extra) => {
		const scope = {
			map: /* @__PURE__ */ new Map(),
			parent
		};
		if (extra) extra.forEach((n) => bind(scope, n));
		body.params = body.params.map((p) => bind(scope, p));
		walkStats(body.body, scope);
	};
	const walkStat = (s, scope) => {
		switch (s.type) {
			case "Assignment":
				s.exps.forEach((e) => walkExp(e, scope));
				s.vars.forEach((v) => walkExp(v, scope));
				break;
			case "CallStat":
				walkExp(s.call, scope);
				break;
			case "Do":
				walkStats(s.body, {
					map: /* @__PURE__ */ new Map(),
					parent: scope
				});
				break;
			case "While":
				walkExp(s.cond, scope);
				walkStats(s.body, {
					map: /* @__PURE__ */ new Map(),
					parent: scope
				});
				break;
			case "Repeat": {
				const inner = {
					map: /* @__PURE__ */ new Map(),
					parent: scope
				};
				walkStats(s.body, inner);
				walkExp(s.cond, inner);
				break;
			}
			case "If":
				for (const c of s.clauses) {
					walkExp(c.test, scope);
					walkStats(c.body, {
						map: /* @__PURE__ */ new Map(),
						parent: scope
					});
				}
				if (s.otherwise) walkStats(s.otherwise, {
					map: /* @__PURE__ */ new Map(),
					parent: scope
				});
				break;
			case "ForNum": {
				walkExp(s.start, scope);
				walkExp(s.last, scope);
				if (s.step) walkExp(s.step, scope);
				const inner = {
					map: /* @__PURE__ */ new Map(),
					parent: scope
				};
				s.name = bind(inner, s.name);
				walkStats(s.body, inner);
				break;
			}
			case "ForIn": {
				s.exps.forEach((e) => walkExp(e, scope));
				const inner = {
					map: /* @__PURE__ */ new Map(),
					parent: scope
				};
				s.names = s.names.map((nm) => bind(inner, nm));
				walkStats(s.body, inner);
				break;
			}
			case "FunctionStat": {
				if (s.name.parts.length === 1 && !s.name.method) {
					const mapped = lookup(scope, s.name.parts[0]);
					if (mapped) s.name.parts[0] = mapped;
				} else {
					const mapped = lookup(scope, s.name.parts[0]);
					if (mapped) s.name.parts[0] = mapped;
				}
				const extras = s.name.method ? ["self"] : [];
				walkBody(s.body, scope, extras);
				break;
			}
			case "LocalFunction":
				s.name = bind(scope, s.name);
				walkBody(s.body, scope);
				break;
			case "Local":
				s.exps?.forEach((e) => walkExp(e, scope));
				s.names = s.names.map((nm) => bind(scope, nm));
				break;
			case "Return": s.exps?.forEach((e) => walkExp(e, scope));
		}
	};
	const walkExp = (e, scope) => {
		switch (e.type) {
			case "Name": {
				const mapped = lookup(scope, e.name);
				if (mapped) e.name = mapped;
				break;
			}
			case "Binary":
				walkExp(e.left, scope);
				walkExp(e.right, scope);
				break;
			case "Unary":
				walkExp(e.arg, scope);
				break;
			case "Paren":
				walkExp(e.exp, scope);
				break;
			case "Table":
				e.fields.forEach((f) => walkField(f, scope));
				break;
			case "Function":
				walkBody(e.body, scope);
				break;
			case "Index":
				walkExp(e.object, scope);
				walkExp(e.key, scope);
				break;
			case "Member":
				walkExp(e.object, scope);
				break;
			case "Call":
				walkExp(e.callee, scope);
				e.args.forEach((a) => walkExp(a, scope));
				break;
			case "IfExp":
				e.clauses.forEach((c) => {
					walkExp(c.test, scope);
					walkExp(c.value, scope);
				});
				walkExp(e.otherwise, scope);
		}
	};
	const walkField = (f, scope) => {
		walkExp(f.value, scope);
		if (f.kind === "index") walkExp(f.key, scope);
	};
	walkStats(chunk.body, { map: /* @__PURE__ */ new Map() });
	return { locals: n };
}
function toBase(n, base) {
	return n.toString(base);
}
function confuseName(n, rng) {
	const alphabet = [
		"l",
		"I",
		"O",
		"0",
		"o",
		"_"
	];
	let s = "_";
	const len = 6 + n % 5;
	for (let i = 0; i < len; i++) s += alphabet[rng.int(alphabet.length)];
	s += n.toString(16);
	return s;
}
function replaceStrings(chunk, decode, members) {
	const mapExp = (e) => {
		switch (e.type) {
			case "String": return decode(e.value);
			case "Binary": return {
				...e,
				left: mapExp(e.left),
				right: mapExp(e.right)
			};
			case "Unary": return {
				...e,
				arg: mapExp(e.arg)
			};
			case "Paren": return {
				...e,
				exp: mapExp(e.exp)
			};
			case "Table": return {
				...e,
				fields: e.fields.map((f) => {
					if (f.kind === "list") return {
						...f,
						value: mapExp(f.value)
					};
					if (f.kind === "index") return {
						...f,
						key: mapExp(f.key),
						value: mapExp(f.value)
					};
					if (members) return {
						kind: "index",
						key: decode(f.name),
						value: mapExp(f.value)
					};
					return {
						...f,
						value: mapExp(f.value)
					};
				})
			};
			case "Function": return {
				...e,
				body: mapBody(e.body)
			};
			case "Index": return {
				...e,
				object: mapExp(e.object),
				key: mapExp(e.key)
			};
			case "Member": {
				const object = mapExp(e.object);
				if (members) return {
					type: "Index",
					object,
					key: decode(e.name)
				};
				return {
					...e,
					object
				};
			}
			case "Call": {
				const callee = mapExp(e.callee);
				const args = e.args.map(mapExp);
				if (members && e.method) return desugarMethod(callee, e.method, args, decode);
				return {
					...e,
					callee,
					args
				};
			}
			case "IfExp": return {
				...e,
				clauses: e.clauses.map((c) => ({
					test: mapExp(c.test),
					value: mapExp(c.value)
				})),
				otherwise: mapExp(e.otherwise)
			};
			default: return e;
		}
	};
	const mapBody = (b) => ({
		...b,
		body: b.body.map(mapStat)
	});
	const mapStat = (s) => {
		switch (s.type) {
			case "Assignment": return {
				...s,
				vars: s.vars.map(mapExp),
				exps: s.exps.map(mapExp)
			};
			case "CallStat": return {
				...s,
				call: mapExp(s.call)
			};
			case "Do": return {
				...s,
				body: s.body.map(mapStat)
			};
			case "While": return {
				...s,
				cond: mapExp(s.cond),
				body: s.body.map(mapStat)
			};
			case "Repeat": return {
				...s,
				body: s.body.map(mapStat),
				cond: mapExp(s.cond)
			};
			case "If": return {
				...s,
				clauses: s.clauses.map((c) => ({
					test: mapExp(c.test),
					body: c.body.map(mapStat)
				})),
				otherwise: s.otherwise?.map(mapStat)
			};
			case "ForNum": return {
				...s,
				start: mapExp(s.start),
				last: mapExp(s.last),
				step: s.step ? mapExp(s.step) : void 0,
				body: s.body.map(mapStat)
			};
			case "ForIn": return {
				...s,
				exps: s.exps.map(mapExp),
				body: s.body.map(mapStat)
			};
			case "FunctionStat": return {
				...s,
				body: mapBody(s.body)
			};
			case "LocalFunction": return {
				...s,
				body: mapBody(s.body)
			};
			case "Local": return {
				...s,
				exps: s.exps?.map(mapExp)
			};
			case "Return": return {
				...s,
				exps: s.exps?.map(mapExp)
			};
			default: return s;
		}
	};
	chunk.body = chunk.body.map(mapStat);
}
function desugarMethod(object, method, args, decode) {
	if (object.type === "Name") return {
		type: "Call",
		callee: {
			type: "Index",
			object,
			key: decode(method)
		},
		args: [object, ...args]
	};
	return {
		type: "Call",
		callee: {
			type: "Function",
			body: {
				params: ["_o"],
				vararg: false,
				body: [{
					type: "Return",
					exps: [{
						type: "Call",
						callee: {
							type: "Index",
							object: {
								type: "Name",
								name: "_o"
							},
							key: decode(method)
						},
						args: [{
							type: "Name",
							name: "_o"
						}, ...args]
					}]
				}]
			}
		},
		args: [object]
	};
}
function rewriteNumbers(chunk, rng, intensity) {
	const mapExp = (e) => {
		switch (e.type) {
			case "Number": return obfuscateNumber(e.value, rng, intensity);
			case "Binary": return {
				...e,
				left: mapExp(e.left),
				right: mapExp(e.right)
			};
			case "Unary": return {
				...e,
				arg: mapExp(e.arg)
			};
			case "Paren": return {
				...e,
				exp: mapExp(e.exp)
			};
			case "Table": return {
				...e,
				fields: e.fields.map((f) => {
					if (f.kind === "index") return {
						...f,
						key: mapExp(f.key),
						value: mapExp(f.value)
					};
					return {
						...f,
						value: mapExp(f.value)
					};
				})
			};
			case "Function": return {
				...e,
				body: {
					...e.body,
					body: e.body.body.map(mapStat)
				}
			};
			case "Index": return {
				...e,
				object: mapExp(e.object),
				key: mapExp(e.key)
			};
			case "Member": return {
				...e,
				object: mapExp(e.object)
			};
			case "Call": return {
				...e,
				callee: mapExp(e.callee),
				args: e.args.map(mapExp)
			};
			case "IfExp": return {
				...e,
				clauses: e.clauses.map((c) => ({
					test: mapExp(c.test),
					value: mapExp(c.value)
				})),
				otherwise: mapExp(e.otherwise)
			};
			default: return e;
		}
	};
	const mapStat = (s) => {
		switch (s.type) {
			case "Assignment": return {
				...s,
				vars: s.vars.map(mapExp),
				exps: s.exps.map(mapExp)
			};
			case "CallStat": return {
				...s,
				call: mapExp(s.call)
			};
			case "Do": return {
				...s,
				body: s.body.map(mapStat)
			};
			case "While": return {
				...s,
				cond: mapExp(s.cond),
				body: s.body.map(mapStat)
			};
			case "Repeat": return {
				...s,
				body: s.body.map(mapStat),
				cond: mapExp(s.cond)
			};
			case "If": return {
				...s,
				clauses: s.clauses.map((c) => ({
					test: mapExp(c.test),
					body: c.body.map(mapStat)
				})),
				otherwise: s.otherwise?.map(mapStat)
			};
			case "ForNum": return {
				...s,
				start: mapExp(s.start),
				last: mapExp(s.last),
				step: s.step ? mapExp(s.step) : void 0,
				body: s.body.map(mapStat)
			};
			case "ForIn": return {
				...s,
				exps: s.exps.map(mapExp),
				body: s.body.map(mapStat)
			};
			case "FunctionStat": return {
				...s,
				body: {
					...s.body,
					body: s.body.body.map(mapStat)
				}
			};
			case "LocalFunction": return {
				...s,
				body: {
					...s.body,
					body: s.body.body.map(mapStat)
				}
			};
			case "Local": return {
				...s,
				exps: s.exps?.map(mapExp)
			};
			case "Return": return {
				...s,
				exps: s.exps?.map(mapExp)
			};
			default: return s;
		}
	};
	chunk.body = chunk.body.map(mapStat);
}
function obfuscateNumber(n, rng, intensity) {
	if (!Number.isFinite(n)) return {
		type: "Number",
		value: n,
		raw: String(n)
	};
	if (!Number.isInteger(n) || Math.abs(n) > 2147483647) {
		if (intensity < 1) return {
			type: "Number",
			value: n,
			raw: String(n)
		};
		const a = rng.int(40) + 1;
		return {
			type: "Binary",
			op: "-",
			left: {
				type: "Number",
				value: n + a,
				raw: String(n + a)
			},
			right: {
				type: "Number",
				value: a,
				raw: String(a)
			}
		};
	}
	const mode = rng.int(2 + intensity);
	const a = rng.int(80) + 3;
	if (mode === 0) return {
		type: "Binary",
		op: "-",
		left: {
			type: "Number",
			value: n + a,
			raw: String(n + a)
		},
		right: {
			type: "Number",
			value: a,
			raw: String(a)
		}
	};
	if (mode === 1) return xorCall((n ^ a) >>> 0, a);
	const b = rng.int(50) + 2;
	return {
		type: "Binary",
		op: "+",
		left: {
			type: "Binary",
			op: "-",
			left: {
				type: "Number",
				value: n + a,
				raw: String(n + a)
			},
			right: {
				type: "Number",
				value: a,
				raw: String(a)
			}
		},
		right: {
			type: "Binary",
			op: "-",
			left: {
				type: "Number",
				value: b,
				raw: String(b)
			},
			right: {
				type: "Number",
				value: b,
				raw: String(b)
			}
		}
	};
}
function xorCall(a, b) {
	return {
		type: "Call",
		callee: {
			type: "Member",
			object: {
				type: "Name",
				name: "bit32"
			},
			name: "bxor"
		},
		args: [{
			type: "Number",
			value: a,
			raw: "0x" + a.toString(16)
		}, {
			type: "Number",
			value: b,
			raw: "0x" + b.toString(16)
		}]
	};
}
function injectOpaque(chunk, rng, density) {
	const wrap = (stats) => {
		const out = [];
		for (const s of stats) {
			const mapped = mapStat(s);
			if (rng.next() < density && canWrap(mapped)) {
				const k = rng.int(200) + 7;
				out.push({
					type: "If",
					clauses: [{
						test: {
							type: "Binary",
							op: "==",
							left: xorCall(k, k),
							right: {
								type: "Number",
								value: 0,
								raw: "0"
							}
						},
						body: [mapped]
					}],
					otherwise: rng.next() < .5 ? junkBlock(rng) : void 0
				});
			} else out.push(mapped);
		}
		return out;
	};
	const mapStat = (s) => {
		switch (s.type) {
			case "Do": return {
				...s,
				body: wrap(s.body)
			};
			case "While": return {
				...s,
				body: wrap(s.body)
			};
			case "Repeat": return {
				...s,
				body: wrap(s.body)
			};
			case "If": return {
				...s,
				clauses: s.clauses.map((c) => ({
					...c,
					body: wrap(c.body)
				})),
				otherwise: s.otherwise ? wrap(s.otherwise) : void 0
			};
			case "ForNum": return {
				...s,
				body: wrap(s.body)
			};
			case "ForIn": return {
				...s,
				body: wrap(s.body)
			};
			case "FunctionStat": return {
				...s,
				body: {
					...s.body,
					body: wrap(s.body.body)
				}
			};
			case "LocalFunction": return {
				...s,
				body: {
					...s.body,
					body: wrap(s.body.body)
				}
			};
			default: return s;
		}
	};
	chunk.body = wrap(chunk.body);
}
function canWrap(s) {
	return s.type !== "Local" && s.type !== "LocalFunction" && s.type !== "Return" && s.type !== "Break" && s.type !== "Continue";
}
function junkBlock(rng) {
	const n = rng.int(4) + 1;
	const name = `_j${rng.int(9999)}`;
	return [{
		type: "Local",
		names: [name],
		exps: [{
			type: "Number",
			value: n,
			raw: String(n)
		}]
	}, {
		type: "Assignment",
		vars: [{
			type: "Name",
			name
		}],
		exps: [{
			type: "Binary",
			op: "+",
			left: {
				type: "Name",
				name
			},
			right: {
				type: "Number",
				value: 0,
				raw: "0"
			}
		}]
	}];
}
function wrapChunk(chunk, prelude) {
	return {
		type: "Chunk",
		body: [{
			type: "Return",
			exps: [{
				type: "Call",
				callee: {
					type: "Paren",
					exp: {
						type: "Function",
						body: {
							params: [],
							vararg: true,
							body: [...prelude, ...chunk.body]
						}
					}
				},
				args: [{ type: "Vararg" }]
			}]
		}]
	};
}
var Rng = class {
	s;
	seed;
	constructor(seed) {
		this.seed = seed === void 0 ? Math.floor(Math.random() * 4294967295) >>> 0 : seed >>> 0;
		this.s = this.seed || 2654435769;
	}
	next() {
		let t = this.s += 1831565813;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	}
	int(max) {
		return Math.floor(this.next() * max);
	}
	pick(arr) {
		return arr[this.int(arr.length)];
	}
	bytes(n) {
		const out = [];
		for (let i = 0; i < n; i++) out.push(this.int(256));
		return out;
	}
};
var PRESETS = {
	light: {
		rename: true,
		encryptStrings: true,
		encryptMembers: false,
		numbers: false,
		controlFlow: false,
		minify: true,
		vmWrap: false
	},
	medium: {
		rename: true,
		encryptStrings: true,
		encryptMembers: true,
		numbers: true,
		controlFlow: false,
		minify: true,
		vmWrap: false
	},
	heavy: {
		rename: true,
		encryptStrings: true,
		encryptMembers: true,
		numbers: true,
		controlFlow: true,
		minify: true,
		vmWrap: false
	},
	maximum: {
		rename: true,
		encryptStrings: true,
		encryptMembers: true,
		numbers: true,
		controlFlow: true,
		minify: true,
		vmWrap: true
	}
};
function resolveOptions(opts = {}) {
	const preset = opts.preset ?? "heavy";
	const base = PRESETS[preset];
	return {
		preset,
		seed: opts.seed ?? 0,
		rename: opts.rename ?? base.rename,
		encryptStrings: opts.encryptStrings ?? base.encryptStrings,
		encryptMembers: opts.encryptMembers ?? base.encryptMembers,
		numbers: opts.numbers ?? base.numbers,
		controlFlow: opts.controlFlow ?? base.controlFlow,
		minify: opts.minify ?? base.minify,
		vmWrap: opts.vmWrap ?? base.vmWrap
	};
}
function obfuscate(source, opts = {}) {
	const resolved = resolveOptions(opts);
	const rng = new Rng(opts.seed);
	const originalBytes = byteLen(source);
	try {
		return finalize(obfuscateAst(source, resolved, rng), originalBytes, rng.seed);
	} catch (err) {
		const parseError = err instanceof ParseError ? err.message : err instanceof Error ? err.message : String(err);
		return finalize({
			output: wrapEncrypted(source, rng, "wrapper"),
			mode: "wrapper",
			localsRenamed: 0,
			stringsEncrypted: 1,
			warning: "Could not fully parse — encrypted the whole script as a loader.",
			parseError
		}, originalBytes, rng.seed);
	}
}
function obfuscateAst(source, opts, rng) {
	const chunk = parse(source);
	stripEmpty(chunk);
	let localsRenamed = 0;
	if (opts.rename) localsRenamed = renameLocals(chunk, rng, opts.preset === "light" ? "short" : opts.preset === "medium" ? "hex" : "confuse").locals;
	let stringsEncrypted = 0;
	const prelude = [];
	if (opts.encryptStrings) {
		const key = rng.bytes(8 + rng.int(8));
		const keyName = unique("k", rng);
		const decName = unique("d", rng);
		const poolName = unique("s", rng);
		const pool = [];
		const index = /* @__PURE__ */ new Map();
		const intern = (value) => {
			const hit = index.get(value);
			if (hit) return hit;
			pool.push(value);
			index.set(value, pool.length);
			return pool.length;
		};
		const decode = (value) => {
			stringsEncrypted += 1;
			const idx = intern(value);
			return {
				type: "Index",
				object: {
					type: "Name",
					name: poolName
				},
				key: opts.numbers ? {
					type: "Binary",
					op: "-",
					left: {
						type: "Number",
						value: idx + 9,
						raw: String(idx + 9)
					},
					right: {
						type: "Number",
						value: 9,
						raw: "9"
					}
				} : {
					type: "Number",
					value: idx,
					raw: String(idx)
				}
			};
		};
		replaceStrings(chunk, decode, opts.encryptMembers);
		prelude.push({
			type: "Local",
			names: [keyName],
			exps: [{
				type: "Table",
				fields: key.map((n) => ({
					kind: "list",
					value: {
						type: "Number",
						value: n,
						raw: "0x" + n.toString(16)
					}
				}))
			}]
		});
		prelude.push(makeDecoder(decName, keyName));
		prelude.push({
			type: "Local",
			names: [poolName],
			exps: [{
				type: "Table",
				fields: pool.map((s) => ({
					kind: "list",
					value: {
						type: "Call",
						callee: {
							type: "Name",
							name: decName
						},
						args: [{
							type: "String",
							value: xorLatin1(s, key)
						}]
					}
				}))
			}]
		});
	}
	if (opts.numbers) rewriteNumbers(chunk, rng, opts.preset === "light" ? 1 : 2);
	if (opts.controlFlow) injectOpaque(chunk, rng, opts.preset === "maximum" ? .55 : .32);
	let output = emit(wrapChunk(chunk, prelude), { minify: opts.minify });
	output = banner(rng.seed) + output;
	if (opts.vmWrap) output = wrapEncrypted(output, rng, "vm");
	return {
		output,
		mode: "ast",
		localsRenamed,
		stringsEncrypted
	};
}
function makeDecoder(decName, keyName) {
	return {
		type: "Local",
		names: [decName],
		exps: [{
			type: "Function",
			body: {
				params: ["a"],
				vararg: false,
				body: [
					{
						type: "Local",
						names: ["r"],
						exps: [{
							type: "Table",
							fields: []
						}]
					},
					{
						type: "ForNum",
						name: "i",
						start: {
							type: "Number",
							value: 1,
							raw: "1"
						},
						last: {
							type: "Unary",
							op: "#",
							arg: {
								type: "Name",
								name: "a"
							}
						},
						body: [{
							type: "Assignment",
							vars: [{
								type: "Index",
								object: {
									type: "Name",
									name: "r"
								},
								key: {
									type: "Name",
									name: "i"
								}
							}],
							exps: [{
								type: "Call",
								callee: {
									type: "Member",
									object: {
										type: "Name",
										name: "string"
									},
									name: "char"
								},
								args: [{
									type: "Call",
									callee: {
										type: "Member",
										object: {
											type: "Name",
											name: "bit32"
										},
										name: "bxor"
									},
									args: [{
										type: "Call",
										callee: {
											type: "Member",
											object: {
												type: "Name",
												name: "string"
											},
											name: "byte"
										},
										args: [{
											type: "Name",
											name: "a"
										}, {
											type: "Name",
											name: "i"
										}]
									}, {
										type: "Index",
										object: {
											type: "Name",
											name: keyName
										},
										key: {
											type: "Binary",
											op: "+",
											left: {
												type: "Binary",
												op: "%",
												left: {
													type: "Binary",
													op: "-",
													left: {
														type: "Name",
														name: "i"
													},
													right: {
														type: "Number",
														value: 1,
														raw: "1"
													}
												},
												right: {
													type: "Unary",
													op: "#",
													arg: {
														type: "Name",
														name: keyName
													}
												}
											},
											right: {
												type: "Number",
												value: 1,
												raw: "1"
											}
										}
									}]
								}]
							}]
						}]
					},
					{
						type: "Return",
						exps: [{
							type: "Call",
							callee: {
								type: "Member",
								object: {
									type: "Name",
									name: "table"
								},
								name: "concat"
							},
							args: [{
								type: "Name",
								name: "r"
							}]
						}]
					}
				]
			}
		}]
	};
}
function wrapEncrypted(source, rng, _why) {
	const key = rng.bytes(12);
	const payload = xorLatin1(source, key);
	const body = [
		`local _k=${"{" + key.map((n) => "0x" + n.toString(16)).join(",") + "}"}`,
		`local _d=function(s)local r={}for i=1,#s do r[i]=string.char(bit32.bxor(string.byte(s,i),_k[(i-1)%#_k+1]))end return table.concat(r)end`,
		`local _l=loadstring or load`,
		`local _f=_l(_d(${quoteLua(payload)}))`,
		`if not _f then error("veil: load failed")end`,
		`return _f(...)`
	].join(" ");
	return `${banner(rng.seed)}return(function(...) ${body} end)(...)`;
}
function buildExecutorKit(seed) {
	const rng = new Rng(seed);
	const stamp = rng.seed.toString(16).padStart(8, "0");
	return `--[[
  VEIL kit  ·  ${stamp}
  Paste this into a Luau executor.

    local out = veil([[ print("hello") ]])
    if setclipboard then setclipboard(out) end
    print(out)
]]

function veil(src)
  src = tostring(src)
  local k = {${Array.from({ length: 10 }, () => rng.int(256)).join(", ")}}
  local function enc(s)
    local r = {}
    for i = 1, #s do
      r[i] = string.char(bit32.bxor(string.byte(s, i), k[(i - 1) % #k + 1]))
    end
    return table.concat(r)
  end
  local function lit(s)
    local r = {'"'}
    for i = 1, #s do
      r[#r + 1] = "\\\\"
      r[#r + 1] = string.format("%03d", string.byte(s, i))
    end
    r[#r + 1] = '"'
    return table.concat(r)
  end
  local payload = lit(enc(src))
  local keylit = "{" .. table.concat(k, ",") .. "}"
  return table.concat({
    "-- veil ${stamp}\\n",
    "return(function(...) ",
    "local _k=",
    keylit,
    " local _d=function(s)local r={}for i=1,#s do r[i]=string.char(bit32.bxor(string.byte(s,i),_k[(i-1)%#_k+1]))end return table.concat(r)end ",
    "local _l=loadstring or load local _f=_l(_d(",
    payload,
    ")) if not _f then error(\\"veil: load failed\\") end return _f(...) end)(...)",
  })
end
`;
}
function xorLatin1(text, key) {
	const bytes = utf8Bytes(text);
	let out = "";
	for (let i = 0; i < bytes.length; i++) out += String.fromCharCode(bytes[i] ^ key[i % key.length]);
	return out;
}
function utf8Bytes(text) {
	const encoded = new TextEncoder().encode(text);
	return Array.from(encoded);
}
function unique(prefix, rng) {
	return `_${prefix}${rng.int(65535).toString(16)}${rng.int(4095).toString(16)}`;
}
function banner(seed) {
	return `-- veil ${seed.toString(16).padStart(8, "0")}\n`;
}
function byteLen(s) {
	return new TextEncoder().encode(s).length;
}
function stripEmpty(chunk) {
	const clean = (stats) => {
		const out = [];
		for (const s of stats) {
			if (s.type === "Do" && s.body.length === 0) continue;
			if (s.type === "Do") out.push({
				...s,
				body: clean(s.body)
			});
			else if (s.type === "While") out.push({
				...s,
				body: clean(s.body)
			});
			else if (s.type === "Repeat") out.push({
				...s,
				body: clean(s.body)
			});
			else if (s.type === "If") out.push({
				...s,
				clauses: s.clauses.map((c) => ({
					...c,
					body: clean(c.body)
				})),
				otherwise: s.otherwise ? clean(s.otherwise) : void 0
			});
			else if (s.type === "ForNum") out.push({
				...s,
				body: clean(s.body)
			});
			else if (s.type === "ForIn") out.push({
				...s,
				body: clean(s.body)
			});
			else if (s.type === "FunctionStat") out.push({
				...s,
				body: {
					...s.body,
					body: clean(s.body.body)
				}
			});
			else if (s.type === "LocalFunction") out.push({
				...s,
				body: {
					...s.body,
					body: clean(s.body.body)
				}
			});
			else out.push(s);
		}
		return out;
	};
	chunk.body = clean(chunk.body);
}
function finalize(result, originalBytes, seed) {
	return {
		...result,
		seed,
		originalBytes,
		outputBytes: byteLen(result.output)
	};
}
var SAMPLES = [
	{
		id: "hello",
		label: "Hello",
		hint: "Locals, concat, print",
		source: `local name = "world"
local function greet(who)
  print("hello, " .. who)
end

greet(name)
`
	},
	{
		id: "roblox",
		label: "Roblox",
		hint: "GetService + player",
		source: `local Players = game:GetService("Players")
local player = Players.LocalPlayer

local function announce(target)
  if not target then
    return
  end
  print("loaded for " .. target.Name)
end

announce(player)
`
	},
	{
		id: "loops",
		label: "Loops",
		hint: "Tables, for, closures",
		source: `local scores = { alpha = 12, beta = 8, gamma = 21 }

local function total(map)
  local sum = 0
  for key, value in pairs(map) do
    if value > 0 then
      sum += value
    end
  end
  return sum
end

local function makeCounter(start)
  local n = start
  return function(step)
    n += step or 1
    return n
  end
end

local tick = makeCounter(total(scores))
print(tick(3))
print(tick(1))
`
	},
	{
		id: "remote",
		label: "Remote",
		hint: "pcall + WaitForChild",
		source: `local ReplicatedStorage = game:GetService("ReplicatedStorage")
local remote = ReplicatedStorage:WaitForChild("Ping")

local function ping(payload)
  local ok, result = pcall(function()
    return remote:InvokeServer(payload)
  end)
  if ok then
    return result
  end
  warn("ping failed")
  return nil
end

print(ping({ t = os.clock(), v = 1 }))
`
	}
];
var STORAGE_KEY = "veil:v1";
var PRESET_META = [
	{
		id: "light",
		label: "Light",
		blurb: "Names + strings"
	},
	{
		id: "medium",
		label: "Medium",
		blurb: "Members + numbers"
	},
	{
		id: "heavy",
		label: "Heavy",
		blurb: "Opaque control flow"
	},
	{
		id: "maximum",
		label: "Max",
		blurb: "Encrypted loadstring"
	}
];
function loadState() {
	const fallback = {
		source: SAMPLES[1]?.source ?? SAMPLES[0].source,
		preset: "heavy",
		passes: { ...PRESETS.heavy }
	};
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return fallback;
		const parsed = JSON.parse(raw);
		return {
			source: typeof parsed.source === "string" ? parsed.source : fallback.source,
			preset: parsed.preset && parsed.preset in PRESETS ? parsed.preset : fallback.preset,
			passes: {
				...PRESETS.heavy,
				...parsed.passes
			}
		};
	} catch {
		return fallback;
	}
}
function VeilApp() {
	const [source, setSource] = (0, import_react.useState)(SAMPLES[1].source);
	const [preset, setPreset] = (0, import_react.useState)("heavy");
	const [passes, setPasses] = (0, import_react.useState)({ ...PRESETS.heavy });
	const [sampleId, setSampleId] = (0, import_react.useState)("roblox");
	const [seed, setSeed] = (0, import_react.useState)(void 0);
	const [result, setResult] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)(null);
	const [pane, setPane] = (0, import_react.useState)("output");
	const [passesOpen, setPassesOpen] = (0, import_react.useState)(false);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const kit = (0, import_react.useMemo)(() => buildExecutorKit(seed), [seed]);
	(0, import_react.useEffect)(() => {
		const saved = loadState();
		setSource(saved.source);
		setPreset(saved.preset);
		setPasses(saved.passes);
		setSampleId(null);
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		localStorage.setItem(STORAGE_KEY, JSON.stringify({
			source,
			preset,
			passes
		}));
	}, [
		hydrated,
		source,
		preset,
		passes
	]);
	const applyPreset = (id) => {
		setPreset(id);
		setPasses({ ...PRESETS[id] });
	};
	const run = (0, import_react.useCallback)((seedOverride) => {
		setError(null);
		try {
			const next = obfuscate(source, {
				...passes,
				preset,
				seed: seedOverride ?? seed
			});
			setResult(next);
			setSeed(next.seed);
			setPane("output");
		} catch (err) {
			setError(err instanceof Error ? err.message : String(err));
		}
	}, [
		source,
		passes,
		preset,
		seed
	]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
				e.preventDefault();
				run();
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [run]);
	const copy = async (which) => {
		const text = which === "kit" ? kit : result?.output;
		if (!text) return;
		await navigator.clipboard.writeText(text);
		setCopied(which);
		window.setTimeout(() => setCopied(null), 1400);
	};
	const download = () => {
		if (!result) return;
		const blob = new Blob([result.output], { type: "text/plain;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `veil-${result.seed.toString(16)}.lua`;
		a.click();
		URL.revokeObjectURL(url);
	};
	const ratio = result && result.originalBytes > 0 ? result.outputBytes / result.originalBytes : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between gap-3 border-b border-line px-4 py-3 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-w-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-lg font-semibold tracking-mark text-fg",
						children: "VEIL"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden text-2xs font-medium tracking-kicker text-muted uppercase sm:block",
						children: "Luau obfuscator"
					})]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "ghost",
					size: "sm",
					className: "hidden sm:inline-flex",
					onClick: () => {
						setPane("kit");
						copy("kit");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Terminal, { className: "size-3.5" }), "Executor kit"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "md",
					onClick: () => run(),
					disabled: !source.trim(),
					children: ["Obfuscate", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-2xs font-normal tracking-tight text-accent-fg/60 sm:inline",
						children: "⌘↵"
					})]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid flex-1 grid-cols-1 lg:grid-cols-[18rem_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "border-b border-line lg:border-r lg:border-b-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-6 px-4 py-5 sm:px-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-2xs font-medium tracking-kicker text-subtle uppercase",
							children: "Strength"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2",
							children: PRESET_META.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => applyPreset(p.id),
								className: cn("min-h-14 rounded-md px-3 py-2 text-left transition-[box-shadow,background-color,color] duration-150 ease-out", preset === p.id ? "bg-accent text-accent-fg" : "bg-raised text-fg shadow-border hover:shadow-border-hover"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-medium",
									children: p.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("mt-0.5 block text-2xs", preset === p.id ? "text-accent-fg/70" : "text-muted"),
									children: p.blurb
								})]
							}, p.id))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
							className: "lg:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex h-11 w-full items-center justify-between rounded-sm text-sm font-medium text-fg",
								onClick: () => setPassesOpen((v) => !v),
								children: ["Passes", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: passesOpen ? "Hide" : "Show"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: cn("space-y-1", passesOpen ? "block" : "hidden lg:block"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-2 hidden text-2xs font-medium tracking-kicker text-subtle uppercase lg:block",
									children: "Passes"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
									label: "Rename locals",
									hint: "Mangle local names, keep Roblox globals",
									checked: passes.rename,
									onCheckedChange: (v) => setPasses((p) => ({
										...p,
										rename: v
									}))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
									label: "Encrypt strings",
									hint: "XOR pool + runtime decoder",
									checked: passes.encryptStrings,
									onCheckedChange: (v) => setPasses((p) => ({
										...p,
										encryptStrings: v
									}))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
									label: "Encrypt members",
									hint: "GetService and fields become indexed",
									checked: passes.encryptMembers,
									onCheckedChange: (v) => setPasses((p) => ({
										...p,
										encryptMembers: v
									}))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
									label: "Number math",
									hint: "Rewrite constants as expressions",
									checked: passes.numbers,
									onCheckedChange: (v) => setPasses((p) => ({
										...p,
										numbers: v
									}))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
									label: "Opaque flow",
									hint: "Dead branches that always skip",
									checked: passes.controlFlow,
									onCheckedChange: (v) => setPasses((p) => ({
										...p,
										controlFlow: v
									}))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
									label: "Minify",
									hint: "Strip whitespace",
									checked: passes.minify,
									onCheckedChange: (v) => setPasses((p) => ({
										...p,
										minify: v
									}))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchRow, {
									label: "VM wrap",
									hint: "Encrypt the result behind loadstring",
									checked: passes.vmWrap,
									onCheckedChange: (v) => setPasses((p) => ({
										...p,
										vmWrap: v
									}))
								})
							]
						}),
						result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "hidden lg:block",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-3 text-2xs font-medium tracking-kicker text-subtle uppercase",
									children: "Report"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "grid grid-cols-2 gap-x-3 gap-y-3 font-mono text-sm tabular-nums",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: "Mode",
											value: result.mode === "ast" ? "AST" : "Wrap"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: "Seed",
											value: result.seed.toString(16)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: "In",
											value: fmtBytes(result.originalBytes)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: "Out",
											value: fmtBytes(result.outputBytes)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: "Locals",
											value: String(result.localsRenamed)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: "Strings",
											value: String(result.stringsEncrypted)
										})
									]
								}),
								ratio ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-xs text-muted",
									children: [ratio.toFixed(2), "× size · paste into any Luau executor"]
								}) : null
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden text-sm leading-relaxed text-muted text-pretty lg:block",
							children: "Paste Luau, pick a strength, obfuscate. Output is executor-ready — bit32, string, table, and loadstring only."
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex min-h-0 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex min-h-72 flex-col border-b border-line lg:border-r lg:border-b-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 px-4 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xs font-medium tracking-kicker text-subtle uppercase",
								children: "Source"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [SAMPLES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setSource(s.source);
										setSampleId(s.id);
									},
									className: cn("h-11 rounded-sm px-2.5 text-xs font-medium transition-colors duration-150", sampleId === s.id ? "bg-raised text-fg" : "text-muted hover:text-fg"),
									children: s.label
								}, s.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Clear source",
									className: "inline-flex size-11 items-center justify-center rounded-sm text-muted hover:text-fg",
									onClick: () => {
										setSource("");
										setSampleId(null);
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, { className: "size-3.5" })
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: source,
							spellCheck: false,
							autoComplete: "off",
							autoCorrect: "off",
							onChange: (e) => {
								setSource(e.target.value);
								setSampleId(null);
							},
							onKeyDown: (e) => {
								if (e.key === "Tab") {
									e.preventDefault();
									const el = e.currentTarget;
									const start = el.selectionStart;
									const end = el.selectionEnd;
									const next = source.slice(0, start) + "  " + source.slice(end);
									setSource(next);
									requestAnimationFrame(() => {
										el.selectionStart = el.selectionEnd = start + 2;
									});
								}
							},
							placeholder: "Paste Luau here",
							className: "min-h-52 flex-1 resize-none bg-inset px-4 py-3 font-mono text-code leading-relaxed text-fg outline-none placeholder:text-subtle"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "flex min-h-72 flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 px-4 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setPane("output"),
									className: cn("h-11 rounded-sm px-2.5 text-2xs font-medium tracking-kicker uppercase", pane === "output" ? "text-fg" : "text-muted hover:text-fg"),
									children: "Output"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setPane("kit"),
									className: cn("h-11 rounded-sm px-2.5 text-2xs font-medium tracking-kicker uppercase", pane === "kit" ? "text-fg" : "text-muted hover:text-fg"),
									children: "Kit"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-1",
								children: pane === "output" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
										label: "New seed",
										onClick: () => {
											const next = Math.floor(Math.random() * 4294967295);
											run(next);
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "size-3.5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
										label: "Download",
										onClick: download,
										disabled: !result,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
										label: "Copy output",
										onClick: () => void copy("out"),
										disabled: !result,
										children: copied === "out" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-ok" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clipboard, { className: "size-3.5" })
									})
								] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
									label: "Copy kit",
									onClick: () => void copy("kit"),
									children: copied === "kit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 text-ok" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clipboard, { className: "size-3.5" })
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							readOnly: true,
							spellCheck: false,
							value: pane === "kit" ? kit : result?.output ?? "",
							placeholder: pane === "kit" ? "" : "Obfuscated Luau appears here",
							className: "min-h-52 flex-1 resize-none bg-inset px-4 py-3 font-mono text-code leading-relaxed text-fg outline-none placeholder:text-subtle"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-line px-4 py-3 text-xs text-muted",
					children: [
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-danger",
							children: error
						}) : null,
						result?.warning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-warn",
							children: result.warning
						}) : null,
						result && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono tabular-nums text-fg",
								children: [
									fmtBytes(result.originalBytes),
									" → ",
									fmtBytes(result.outputBytes)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono tabular-nums",
								children: result.mode === "ast" ? "AST pipeline" : "encrypted loader"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono tabular-nums",
								children: ["seed ", result.seed.toString(16)]
							}),
							result.parseError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-warn",
								children: ["parse: ", result.parseError]
							}) : null
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Cmd/Ctrl + Enter to obfuscate · output runs in Roblox executors" })
					]
				})]
			})]
		})]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "font-sans text-2xs font-medium tracking-kicker text-subtle uppercase",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "mt-1 text-fg",
		children: value
	})] });
}
function IconBtn({ label, onClick, disabled, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		title: label,
		disabled,
		onClick,
		className: "inline-flex size-11 items-center justify-center rounded-sm text-muted transition-colors duration-150 hover:text-fg disabled:opacity-30",
		children
	});
}
function fmtBytes(n) {
	if (n < 1024) return `${n} B`;
	return `${(n / 1024).toFixed(1)} KB`;
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VeilApp, {});
}
//#endregion
export { Home as component };
