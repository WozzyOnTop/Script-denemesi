//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DZ70XilJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BtPByD9_.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BtPByD9_.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-U_qpgIm-.js"]
	}
} });
//#endregion
export { tsrStartManifest };
