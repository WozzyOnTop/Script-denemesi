import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  Check,
  Clipboard,
  Download,
  Eraser,
  Shuffle,
  Terminal,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { SwitchRow } from "@/components/ui/switch";
import {
  buildExecutorKit,
  obfuscate,
  PRESETS,
  type ObfuscateResult,
  type PresetId,
} from "@/lib/obfuscator";
import { SAMPLES } from "@/lib/obfuscator/samples";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "veil:v1";

type PassState = {
  rename: boolean;
  encryptStrings: boolean;
  encryptMembers: boolean;
  numbers: boolean;
  controlFlow: boolean;
  minify: boolean;
  vmWrap: boolean;
};

const PRESET_META: { id: PresetId; label: string; blurb: string }[] = [
  { id: "light", label: "Light", blurb: "Names + strings" },
  { id: "medium", label: "Medium", blurb: "Members + numbers" },
  { id: "heavy", label: "Heavy", blurb: "Opaque control flow" },
  { id: "maximum", label: "Max", blurb: "Encrypted loadstring" },
];

function loadState(): { source: string; preset: PresetId; passes: PassState } {
  const fallback = {
    source: SAMPLES[1]?.source ?? SAMPLES[0]!.source,
    preset: "heavy" as PresetId,
    passes: { ...PRESETS.heavy },
  };
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<typeof fallback>;
    return {
      source: typeof parsed.source === "string" && parsed.source.trim() ? parsed.source : fallback.source,
      preset: parsed.preset && parsed.preset in PRESETS ? parsed.preset : fallback.preset,
      passes: { ...PRESETS.heavy, ...parsed.passes },
    };
  } catch {
    return fallback;
  }
}

export function VeilApp() {
  const [source, setSource] = useState(SAMPLES[1]!.source);
  const [preset, setPreset] = useState<PresetId>("heavy");
  const [passes, setPasses] = useState<PassState>({ ...PRESETS.heavy });
  const [sampleId, setSampleId] = useState<string | null>("roblox");
  const [seed, setSeed] = useState<number | undefined>(undefined);
  const [result, setResult] = useState<ObfuscateResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<"out" | "kit" | null>(null);
  const [pane, setPane] = useState<"output" | "kit">("output");
  const [passesOpen, setPassesOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  const kit = useMemo(() => buildExecutorKit(seed), [seed]);

  useEffect(() => {
    const saved = loadState();
    setSource(saved.source);
    setPreset(saved.preset);
    setPasses(saved.passes);
    setSampleId(null);
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ source, preset, passes }));
  }, [hydrated, source, preset, passes]);

  const applyPreset = (id: PresetId) => {
    setPreset(id);
    setPasses({ ...PRESETS[id] });
  };

  const run = useCallback(
    (seedOverride?: number) => {
      setError(null);
      try {
        const next = obfuscate(source, {
          ...passes,
          preset,
          seed: seedOverride ?? seed,
        });
        setResult(next);
        setSeed(next.seed);
        setPane("output");
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err));
      }
    },
    [source, passes, preset, seed],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
        e.preventDefault();
        run();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [run]);

  const copy = async (which: "out" | "kit") => {
    const text = which === "kit" ? kit : result?.output;
    if (!text) return;
    await navigator.clipboard.writeText(text);
    setCopied(which);
    window.setTimeout(() => setCopied(null), 1400);
  };

  const download = () => {
    if (!result) return;
    const blob = new Blob([result.output], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `veil-${result.seed.toString(16)}.lua`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const ratio =
    result && result.originalBytes > 0 ? result.outputBytes / result.originalBytes : null;

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="flex items-center justify-between gap-3 border-b border-line px-4 py-3 sm:px-6">
        <div className="min-w-0">
          <div className="flex items-baseline gap-3">
            <h1 className="text-lg font-semibold tracking-mark text-fg">VEIL</h1>
            <p className="hidden text-2xs font-medium tracking-kicker text-muted uppercase sm:block">
              Luau obfuscator
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="hidden sm:inline-flex"
            onClick={() => {
              setPane("kit");
              void copy("kit");
            }}
          >
            <Terminal className="size-3.5" />
            Executor kit
          </Button>
          <Button type="button" size="md" onClick={() => run()} disabled={!source.trim()}>
            Obfuscate
          </Button>
        </div>
      </header>

      <div className="grid flex-1 grid-cols-1 lg:grid-cols-[18rem_minmax(0,1fr)]">
        <aside className="border-b border-line lg:border-r lg:border-b-0">
          <div className="flex flex-col gap-6 px-4 py-5 sm:px-5">
            <section>
              <p className="mb-3 text-2xs font-medium tracking-kicker text-subtle uppercase">
                Strength
              </p>
              <div className="grid grid-cols-2 gap-2">
                {PRESET_META.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => applyPreset(p.id)}
                    className={cn(
                      "min-h-14 rounded-md px-3 py-2 text-left transition-[box-shadow,background-color,color] duration-150 ease-out",
                      preset === p.id
                        ? "bg-accent text-accent-fg"
                        : "bg-raised text-fg shadow-border hover:shadow-border-hover",
                    )}
                  >
                    <span className="block text-sm font-medium">{p.label}</span>
                    <span
                      className={cn(
                        "mt-0.5 block text-2xs",
                        preset === p.id ? "text-accent-fg/70" : "text-muted",
                      )}
                    >
                      {p.blurb}
                    </span>
                  </button>
                ))}
              </div>
            </section>

            <section className="lg:hidden">
              <button
                type="button"
                className="flex h-11 w-full items-center justify-between rounded-sm text-sm font-medium text-fg"
                onClick={() => setPassesOpen((v) => !v)}
              >
                Passes
                <span className="text-muted">{passesOpen ? "Hide" : "Show"}</span>
              </button>
            </section>

            <section className={cn("space-y-1", passesOpen ? "block" : "hidden lg:block")}>
              <p className="mb-2 hidden text-2xs font-medium tracking-kicker text-subtle uppercase lg:block">
                Passes
              </p>
              <SwitchRow
                label="Rename locals"
                hint="Mangle local names, keep Roblox globals"
                checked={passes.rename}
                onCheckedChange={(v) => setPasses((p) => ({ ...p, rename: v }))}
              />
              <SwitchRow
                label="Encrypt strings"
                hint="XOR pool + runtime decoder"
                checked={passes.encryptStrings}
                onCheckedChange={(v) => setPasses((p) => ({ ...p, encryptStrings: v }))}
              />
              <SwitchRow
                label="Encrypt members"
                hint="GetService and fields become indexed"
                checked={passes.encryptMembers}
                onCheckedChange={(v) => setPasses((p) => ({ ...p, encryptMembers: v }))}
              />
              <SwitchRow
                label="Number math"
                hint="Rewrite constants as expressions"
                checked={passes.numbers}
                onCheckedChange={(v) => setPasses((p) => ({ ...p, numbers: v }))}
              />
              <SwitchRow
                label="Opaque flow"
                hint="Dead branches that always skip"
                checked={passes.controlFlow}
                onCheckedChange={(v) => setPasses((p) => ({ ...p, controlFlow: v }))}
              />
              <SwitchRow
                label="Minify"
                hint="Strip whitespace"
                checked={passes.minify}
                onCheckedChange={(v) => setPasses((p) => ({ ...p, minify: v }))}
              />
              <SwitchRow
                label="VM wrap"
                hint="Encrypt the result behind loadstring"
                checked={passes.vmWrap}
                onCheckedChange={(v) => setPasses((p) => ({ ...p, vmWrap: v }))}
              />
            </section>

            {result ? (
              <section className="hidden lg:block">
                <p className="mb-3 text-2xs font-medium tracking-kicker text-subtle uppercase">
                  Report
                </p>
                <dl className="grid grid-cols-2 gap-x-3 gap-y-3 font-mono text-sm tabular-nums">
                  <Stat label="Mode" value={result.mode === "ast" ? "AST" : "Wrap"} />
                  <Stat label="Seed" value={result.seed.toString(16)} />
                  <Stat label="In" value={fmtBytes(result.originalBytes)} />
                  <Stat label="Out" value={fmtBytes(result.outputBytes)} />
                  <Stat label="Locals" value={String(result.localsRenamed)} />
                  <Stat label="Strings" value={String(result.stringsEncrypted)} />
                </dl>
                {ratio ? (
                  <p className="mt-3 text-xs text-muted">
                    {ratio.toFixed(2)}× size · paste into any Luau executor
                  </p>
                ) : null}
              </section>
            ) : (
              <p className="hidden text-sm leading-relaxed text-muted text-pretty lg:block">
                Paste Luau, pick a strength, obfuscate. Output is executor-ready — bit32, string,
                table, and loadstring only.
              </p>
            )}
          </div>
        </aside>

        <main className="flex min-h-0 flex-col">
          <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-2">
            <section className="flex min-h-72 flex-col border-b border-line lg:border-r lg:border-b-0">
              <div className="flex items-center justify-between gap-2 px-4 py-2">
                <p className="text-2xs font-medium tracking-kicker text-subtle uppercase">
                  Source
                </p>
                <div className="flex items-center gap-1">
                  {SAMPLES.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => {
                        setSource(s.source);
                        setSampleId(s.id);
                      }}
                      className={cn(
                        "h-11 rounded-sm px-2.5 text-xs font-medium transition-colors duration-150",
                        sampleId === s.id ? "bg-raised text-fg" : "text-muted hover:text-fg",
                      )}
                    >
                      {s.label}
                    </button>
                  ))}
                  <button
                    type="button"
                    aria-label="Clear source"
                    className="inline-flex size-11 items-center justify-center rounded-sm text-muted hover:text-fg"
                    onClick={() => {
                      setSource("");
                      setSampleId(null);
                    }}
                  >
                    <Eraser className="size-3.5" />
                  </button>
                </div>
              </div>
              <textarea
                value={source}
                spellCheck={false}
                autoComplete="off"
                autoCorrect="off"
                onChange={(e) => {
                  setSource(e.target.value);
                  setSampleId(null);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Tab") {
                    e.preventDefault();
                    const el = e.currentTarget;
                    const start = el.selectionStart;
                    const end = el.selectionEnd;
                    const next = source.slice(0, start) + "  " + source.slice(end);
                    setSource(next);
                    requestAnimationFrame(() => {
                      el.selectionStart = el.selectionEnd = start + 2;
                    });
                  }
                }}
                placeholder="Paste Luau here"
                className="min-h-52 flex-1 resize-none bg-inset px-4 py-3 font-mono text-code leading-relaxed text-fg outline-none placeholder:text-subtle"
              />
            </section>

            <section className="flex min-h-72 flex-col">
              <div className="flex items-center justify-between gap-2 px-4 py-2">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setPane("output")}
                    className={cn(
                      "h-11 rounded-sm px-2.5 text-2xs font-medium tracking-kicker uppercase",
                      pane === "output" ? "text-fg" : "text-muted hover:text-fg",
                    )}
                  >
                    Output
                  </button>
                  <button
                    type="button"
                    onClick={() => setPane("kit")}
                    className={cn(
                      "h-11 rounded-sm px-2.5 text-2xs font-medium tracking-kicker uppercase",
                      pane === "kit" ? "text-fg" : "text-muted hover:text-fg",
                    )}
                  >
                    Kit
                  </button>
                </div>
                <div className="flex items-center gap-1">
                  {pane === "output" ? (
                    <>
                      <IconBtn
                        label="New seed"
                        onClick={() => {
                          const next = Math.floor(Math.random() * 0xffffffff);
                          run(next);
                        }}
                      >
                        <Shuffle className="size-3.5" />
                      </IconBtn>
                      <IconBtn label="Download" onClick={download} disabled={!result}>
                        <Download className="size-3.5" />
                      </IconBtn>
                      <IconBtn
                        label="Copy output"
                        onClick={() => void copy("out")}
                        disabled={!result}
                      >
                        {copied === "out" ? (
                          <Check className="size-3.5 text-ok" />
                        ) : (
                          <Clipboard className="size-3.5" />
                        )}
                      </IconBtn>
                    </>
                  ) : (
                    <IconBtn label="Copy kit" onClick={() => void copy("kit")}>
                      {copied === "kit" ? (
                        <Check className="size-3.5 text-ok" />
                      ) : (
                        <Clipboard className="size-3.5" />
                      )}
                    </IconBtn>
                  )}
                </div>
              </div>
              <textarea
                readOnly
                spellCheck={false}
                value={pane === "kit" ? kit : (result?.output ?? "")}
                placeholder={
                  pane === "kit"
                    ? ""
                    : "Obfuscated Luau appears here"
                }
                className="min-h-52 flex-1 resize-none bg-inset px-4 py-3 font-mono text-code leading-relaxed text-fg outline-none placeholder:text-subtle"
              />
            </section>
          </div>

          <footer className="flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-line px-4 py-3 text-xs text-muted">
            {error ? <span className="text-danger">{error}</span> : null}
            {result?.warning ? <span className="text-warn">{result.warning}</span> : null}
            {result && !error ? (
              <>
                <span className="font-mono tabular-nums text-fg">
                  {fmtBytes(result.originalBytes)} → {fmtBytes(result.outputBytes)}
                </span>
                <span className="font-mono tabular-nums">
                  {result.mode === "ast" ? "AST pipeline" : "encrypted loader"}
                </span>
                <span className="font-mono tabular-nums">seed {result.seed.toString(16)}</span>
                {result.parseError ? (
                  <span className="text-warn">parse: {result.parseError}</span>
                ) : null}
              </>
            ) : (
              <span>Cmd/Ctrl + Enter to obfuscate · output runs in Roblox executors</span>
            )}
          </footer>
        </main>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="font-sans text-2xs font-medium tracking-kicker text-subtle uppercase">
        {label}
      </dt>
      <dd className="mt-1 text-fg">{value}</dd>
    </div>
  );
}

function IconBtn({
  label,
  onClick,
  disabled,
  children,
}: {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={onClick}
      className="inline-flex size-11 items-center justify-center rounded-sm text-muted transition-colors duration-150 hover:text-fg disabled:opacity-30"
    >
      {children}
    </button>
  );
}

function fmtBytes(n: number) {
  if (n < 1024) return `${n} B`;
  return `${(n / 1024).toFixed(1)} KB`;
}
