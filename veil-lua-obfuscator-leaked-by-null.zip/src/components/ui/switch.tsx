import { cn } from "@/lib/utils";

type SwitchProps = {
  checked: boolean;
  onCheckedChange: (next: boolean) => void;
  label: string;
  hint?: string;
  disabled?: boolean;
};

export function SwitchRow({ checked, onCheckedChange, label, hint, disabled }: SwitchProps) {
  return (
    <label
      className={cn(
        "flex min-h-11 cursor-pointer items-center justify-between gap-3 rounded-sm px-1",
        disabled && "pointer-events-none opacity-40",
      )}
    >
      <span className="min-w-0">
        <span className="block text-sm font-medium text-fg">{label}</span>
        {hint ? <span className="mt-0.5 block text-xs text-muted">{hint}</span> : null}
      </span>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        disabled={disabled}
        onClick={() => onCheckedChange(!checked)}
        className={cn(
          "relative h-6 w-10 shrink-0 rounded-full transition-colors duration-150 ease-out",
          checked ? "bg-accent" : "bg-faint",
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 left-0.5 size-5 rounded-full transition-transform duration-150 ease-out",
            checked ? "translate-x-4 bg-accent-fg" : "translate-x-0 bg-muted",
          )}
        />
      </button>
    </label>
  );
}
