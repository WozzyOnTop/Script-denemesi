import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { emit } from "./emit.ts";
import { obfuscate, parse, wrapEncrypted } from "./index.ts";
import { Rng } from "./rng.ts";
import { SAMPLES } from "./samples.ts";

const SNIPPETS = [
  `print("hello")`,
  `local a = 1\nprint(a)`,
  `local function f(x)\n  return x + 1\nend\nprint(f(2))`,
  `local t = { a = 1, [2] = "b", 3 }\nprint(t.a)`,
  `if true then print(1) elseif false then print(2) else print(3) end`,
  `for i = 1, 3 do print(i) end`,
  `for k, v in pairs({ a = 1 }) do print(k, v) end`,
  `repeat local x = 1 until x == 1`,
  `local n = 0\nwhile n < 2 do n += 1 end`,
  `game:GetService("Players")`,
  `local p = game.Players.LocalPlayer`,
  `return function(...)\n  return ...\nend`,
  `print(if true then "a" else "b")`,
  `local s = \`hi {1 + 2}\``,
  `local type Foo = number\nlocal x = 1\nprint(x)`,
];

describe("parse + emit", () => {
  for (const src of SNIPPETS) {
    it(`roundtrips ${src.slice(0, 28).replace(/\n/g, " ")}`, () => {
      const ast = parse(src);
      const out = emit(ast, { minify: true });
      assert.ok(out.length > 0);
      parse(out);
    });
  }

  for (const sample of SAMPLES) {
    it(`parses sample ${sample.id}`, () => {
      parse(sample.source);
    });
  }
});

describe("obfuscate", () => {
  it("strips plaintext strings on heavy", () => {
    const src = `local name = "secret-token"\nprint(name)`;
    const result = obfuscate(src, { preset: "heavy", seed: 1, vmWrap: false });
    assert.equal(result.mode, "ast");
    assert.equal(result.output.includes("secret-token"), false);
    assert.match(result.output, /\\[0-9]{3}/);
    assert.ok(result.stringsEncrypted >= 1);
    parse(result.output.replace(/^--[^\n]*\n/, ""));
  });

  it("renames locals", () => {
    const src = `local visible = 1\nprint(visible)`;
    const result = obfuscate(src, { preset: "light", seed: 2 });
    assert.equal(result.output.includes("visible"), false);
    assert.ok(result.localsRenamed >= 1);
  });

  it("keeps roblox globals", () => {
    const src = `local Players = game:GetService("Players")\nprint(Players)`;
    const result = obfuscate(src, { preset: "medium", seed: 3, encryptMembers: false });
    assert.match(result.output, /\bgame\b/);
    assert.equal(result.mode, "ast");
  });

  it("falls back to wrapper on garbage", () => {
    const result = obfuscate(`this is not @@ lua ;;;;`, { preset: "heavy", seed: 4 });
    assert.equal(result.mode, "wrapper");
    assert.match(result.output, /loadstring or load/);
  });

  it("wrapper output is valid lua-ish", () => {
    const out = wrapEncrypted(`print("x")`, new Rng(5), "test");
    parse(out.replace(/^--[^\n]*\n/, ""));
  });

  it("obfuscates every sample", () => {
    for (const sample of SAMPLES) {
      const result = obfuscate(sample.source, { preset: "heavy", seed: 9 });
      assert.ok(result.output.length > 20, sample.id);
      if (result.mode === "ast") {
        parse(result.output.replace(/^--[^\n]*\n/, ""));
      }
    }
  });
});
