export type Sample = {
  id: string;
  label: string;
  hint: string;
  source: string;
};

export const SAMPLES: Sample[] = [
  {
    id: "hello",
    label: "Hello",
    hint: "Locals, concat, print",
    source: `local name = "world"
local function greet(who)
  print("hello, " .. who)
end

greet(name)
`,
  },
  {
    id: "roblox",
    label: "Roblox",
    hint: "GetService + player",
    source: `local Players = game:GetService("Players")
local player = Players.LocalPlayer

local function announce(target)
  if not target then
    return
  end
  print("loaded for " .. target.Name)
end

announce(player)
`,
  },
  {
    id: "loops",
    label: "Loops",
    hint: "Tables, for, closures",
    source: `local scores = { alpha = 12, beta = 8, gamma = 21 }

local function total(map)
  local sum = 0
  for key, value in pairs(map) do
    if value > 0 then
      sum += value
    end
  end
  return sum
end

local function makeCounter(start)
  local n = start
  return function(step)
    n += step or 1
    return n
  end
end

local tick = makeCounter(total(scores))
print(tick(3))
print(tick(1))
`,
  },
  {
    id: "remote",
    label: "Remote",
    hint: "pcall + WaitForChild",
    source: `local ReplicatedStorage = game:GetService("ReplicatedStorage")
local remote = ReplicatedStorage:WaitForChild("Ping")

local function ping(payload)
  local ok, result = pcall(function()
    return remote:InvokeServer(payload)
  end)
  if ok then
    return result
  end
  warn("ping failed")
  return nil
end

print(ping({ t = os.clock(), v = 1 }))
`,
  },
];
